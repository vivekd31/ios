//
//  ProductsDisplayViewController.swift
//  Drakshapally_TableViewDisplay
//
//  Created by student on 11/19/21.
//

import UIKit

class ProductsDisplayViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = productsTableView.dequeueReusableCell(withIdentifier: "showProducts", for: indexPath)
        cell.textLabel?.text = resArray[indexPath.row]
        return cell
    }
    

    @IBOutlet weak var productsTableView: UITableView!
    
    var detailList : String?
    
    var Sports = ["Hockey", "Badminton" ,"Soccer" ,"Cricket" ,"Tennis"]
    var Watches = ["Rolex","PatekPhillipe","Omega","Fasttrack","Titan"]
    var Shoes = ["Nike","Puma","Uspa","Benetton","Lacoste"]
    var resArray = [String]()
    var demoName = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        productsTableView.delegate = self
        productsTableView.dataSource = self
        if detailList == "Sports"
        {
            resArray = Sports
            demoName = "Sports"
        }
        else if detailList == "Watches"{
            resArray = Watches
            demoName = "Watches"
        }
        else{
            resArray = Shoes
            demoName = "Shoes"
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "displayImages"{
            let destination = segue.destination as! DisplayImagesViewController
            destination.imageName = resArray[(productsTableView.indexPathForSelectedRow?.row)!]
            destination.demoName = demoName
        }
    }
    

}
