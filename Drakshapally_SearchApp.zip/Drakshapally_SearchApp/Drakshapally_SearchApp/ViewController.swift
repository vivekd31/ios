//
//  ViewController.swift
//  Drakshapally_SearchApp
//
//  Created by student on 10/12/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchbtn: UIButton!
    
    @IBOutlet weak var searchTextField: UITextField!

    @IBOutlet weak var moreimages: UIButton!
    @IBOutlet weak var topicInfoText: UITextView!
    @IBOutlet weak var resultImage: UIImageView!
    @IBOutlet weak var resetbtn: UIButton!
    let imagesArray = [["Athlete1", "Athlete2", "Athlete3", "Athlete4","Athlete5"],
        ["Leader1", "Leader2", "Leader3", "Leader4","Leader5"],
        ["Car1", "Car2", "Car3", "Car4","Car5"],
        ["Bike1", "Bike2", "Bike3", "Bike4","Bike5"],
                     
                       ["Monument5", "Monument1", "Monument2", "Monument3","Monument4"],
                       ["Whennoresultswerefound"]
    ]
    
    let Athlete_keywords=["Athlete","Game","Sport","Player","Team"]
    
    let Leader_keywords=["Leader","Politician","People","Saviour","Peoplesman"]
    
    let Car_keywords=["Car","Wheeler","Vehicle","FourWheeler","Transport"]
    
    let Bike_keywords=["Bike","TwoWheeler","MotorBike","EasyTransport","MotorCycle"]
    
    let Monument_keywords=["Monument","History","Heritage","Social","Famous"]
    var topic=0
        var image1:Int!
        var image2:Int!
        var image3:Int!
        var image4:Int!
        var image5:Int!
    
    
       
        
        
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //        topicInfoText.text="Hai"
             //   moreImages.isEnabled=false
             moreimages.isHidden=true
             topicInfoText.isHidden=true
             searchbtn.isEnabled=false
             
             resultImage.image=UIImage(named: imagesArray[5][0])
        
    }
    //if the entered key word does not match with any of the key words from the 5 arrays display the blank image

    @IBAction func searchButtonAction(_ sender: Any) {
        image1=0
         image2=0
         image3=0
         image4=0
         image5=0
         moreimages.isHidden=false
         topicInfoText.isHidden=false
         resetbtn.isHidden=false
         if(Athlete_keywords.contains(searchTextField.text!)){
             moreimages.isEnabled=true
             
             resultImage.image=UIImage(named: imagesArray[0][image1])
             topic=1
             topicInfoText.text="The above are some of the famous athletes of the Indian hockey team who also represented hockey in olympics.Recently Indian Hockey team gained the Gold Medal after 44Years."
             
         }
         else if(Leader_keywords.contains(searchTextField.text!)){
             moreimages.isEnabled=true
             resultImage.image=UIImage(named: imagesArray[1][0])
             topic=2
             topicInfoText.text="The above are some of the vital leaders for the different nations who laid their mark in the political history. Who made Sensational Decisions in many situations."
         }
         else if(Car_keywords.contains(searchTextField.text!)){
             moreimages.isEnabled=true
             resultImage.image=UIImage(named: imagesArray[2][image2])
             topic=3
             topicInfoText.text="The above are next-generation cars who compete in the Piston Cup Racing Series.These Cars had Extreme Horse Power which makes Cars to reach High Speed with in 10 Seconds."
             
         }
         else if(Bike_keywords.contains(searchTextField.text!)){
             moreimages.isEnabled=true
             resultImage.image=UIImage(named: imagesArray[3][image3])
             topic=4
             topicInfoText.text="The above are some of the Modern Motor bikes who had Extreme fantasy features which makes people to buy the bikes."
         }
         else if(Monument_keywords.contains(searchTextField.text!)){
             moreimages.isEnabled=true
             resultImage.image=UIImage(named: imagesArray[4][image4])
             topic=5
             topicInfoText.text=" monument is a type of structure that was explicitly created to commemorate a person or event, or which has become relevant to a social group as a part of their remembrance of historic times or cultural heritage, due to its artistic, historical, political, technical or architectural importance."
         }
         else {
             resultImage.image = UIImage(named: imagesArray[5][image5])
             moreimages.isHidden=true
             topicInfoText.isHidden=true
             searchbtn.isEnabled=false
         }
       
    }
    
    @IBAction func showMoreImagesBtn(_ sender: Any) {
        // if(topicInfoText.tex){
                
                //  }
                if(topic==1){
                    image1+=1
                    updateData(imgNum: image1)
                }
                if(topic==2){
                    
                    image2+=1
                    updateData(imgNum: image2)
                }
                if(topic==3){
                    
                    image3+=1
                    updateData(imgNum: image3)
                }
                if(topic==4){
                    
                    image4+=1
                    updateData(imgNum: image4)
                }
                if(topic==5){
                    
                    image5+=1
                    updateData(imgNum: 2)
                }
                
                
                
            }
            
            func updateData(imgNum: Int){
                if(topic==1){
                    
                    if  image1 == imagesArray[0].count  {
                        
                        moreimages.isEnabled = false
                        
                    }else{
                        resultImage.image = UIImage(named: imagesArray[0][image1])
                        
                    }
                }
                if(topic==2){
                    if(image2==imagesArray[1].count){
                        moreimages.isEnabled=false
                    }else{
                        resultImage.image=UIImage(named: imagesArray[1][image2])
                    }
                }
                if(topic==3){
                    if(image3==imagesArray[2].count){
                        moreimages.isEnabled=false
                    }else{
                        resultImage.image=UIImage(named: imagesArray[2][image3])
                    }
                    
                }
                if(topic==4){
                    if(image4==imagesArray[3].count){
                        moreimages.isEnabled=false
                    }else{
                        resultImage.image=UIImage(named: imagesArray[3][image4])
                    }
                }
                if(topic==5){
                    if(image5==imagesArray[4].count){
                        moreimages.isEnabled=false
                    }else{
                        resultImage.image=UIImage(named: imagesArray[4][image5])
                    }
                }
      
    }
    
    @IBAction func ResetButtonClicked(_ sender: Any) {
        topicInfoText.isHidden=true
               moreimages.isHidden=true
               searchbtn.isEnabled=false
               resetbtn.isHidden=true
               resultImage.image=UIImage(named: imagesArray[5][0])
               searchTextField.text=""
        
    }
    @IBAction func searchTextFieldChanged(_ sender: UITextField) {
        searchbtn.isEnabled=true
               if(sender.text==""){
                   searchbtn.isEnabled=false
               }
               
           }
    
    
}

