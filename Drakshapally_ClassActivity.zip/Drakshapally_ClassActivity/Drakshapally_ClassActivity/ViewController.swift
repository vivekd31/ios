//
//  ViewController.swift
//  Drakshapally_ClassActivity
//
//  Created by student on 10/14/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Amount: UITextField!
    
    @IBOutlet weak var Discount: UITextField!
    
   
    @IBOutlet weak var discountprice: UILabel!
    
   
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
   

    @IBAction func Calculate(_ sender: Any) {
    //Assigning  Amount to Variable A
        let A = Double (Amount.text!)
    // Assigning Discount to Variable B
        let B = Double (Discount.text!)
        
        var discountprice: Double = 0.0
        discountprice = Double (A?,0) * Double (B?,0)
        discountprice = discountprice / 100.0
        discountprice = Double (A ?? 0) - discountprice;
        
        var res = "Amount : $\(A!) \nDiscount : $\(d!) \nPrice after Discount: $\(discountprice)"
                
                discountprice.text = res
        
        
                
        
        
        
        
        }
    }


