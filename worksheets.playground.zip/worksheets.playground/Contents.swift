import UIKit

var str1 = "Hii"
var d1 = 10
var d2 = 12.25
print(str1, d1, d2, separator:",")

var programminglanguage = "swift"
print("My favourite programminglanguage is \(programminglanguage)")

var age=23
print("You are \(age) years old and in another \(age) years, You will be \(age * 2)")






