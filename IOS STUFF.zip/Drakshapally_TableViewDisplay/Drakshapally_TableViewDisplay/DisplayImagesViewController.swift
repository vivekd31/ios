//
//  DisplayImagesViewController.swift
//  Drakshapally_TableViewDisplay
//
//  Created by student on 11/19/21.
//

import UIKit

class DisplayImagesViewController: UIViewController {

    @IBOutlet weak var displayLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    var imageName = ""
    var demoName = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        print(imageName)
        imageView.image = UIImage(named: "\(imageName)")
    }
    
    @IBAction func getInfo(_ sender: Any) {
        
        if demoName == "Sports"{
            displayLabel.text = "Sport pertains to any form of competitive physical activity or game that aims to use, maintain or improve physical ability and skills while providing enjoyment to participants and, in some cases, entertainment to spectators.Sports can, through casual or organized participation, improve one's physical health."
        }
        else if demoName == "Watches"
        {
            displayLabel.text = "A watch is a portable timepiece intended to be carried or worn by a person. It is designed to keep a consistent movement despite the motions caused by the person's activities. A wristwatch is designed to be worn around the wrist, attached by a watch strap or other type of bracelet, including metal bands, leather straps or any other kind of bracelet. A pocket watch is designed for a person to carry in a pocket, often attached to a chain."
        }
        else{
            displayLabel.text = "A shoe is an item of footwear intended to protect and comfort the human foot. Shoes are also used as an item of decoration and fashion. The design of shoes has varied enormously through time and from culture to culture, with form originally being tied to function. Though the human foot can adapt to varied terrains and climate conditions, it is still vulnerable to environmental hazards such as sharp rocks and temperature extremes, which shoes protect against."
        }
    }
    
    

}
