//
//  ViewController.swift
//  Drakshapally_ConvertTemperature
//
//  Created by student on 11/5/21.
//

import UIKit

class ViewController: UIViewController {
    var inputDegrees:String = ""
    var newfahrenHeit:Double = 0.0
    var newKelvin:Double = 0.0

    @IBOutlet weak var tempTextField: UITextField!
    @IBOutlet weak var convertButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        convertButton.isEnabled = false
    }
    func inputValidation() {
        let inputEntered = tempTextField.text!
        if inputEntered.isEmpty {
            convertButton.isEnabled = false
            
        }else{
            convertButton.isEnabled = true
            

        }
        let inputIsInt = Int(tempTextField.text!)
        if inputIsInt != nil {
            convertButton.isEnabled = true
            
        }else{
            
            convertButton.isEnabled = false
            
        }
    }
    @IBAction func convertButtonPressed(_ sender: Any) {
    }
    @IBAction func TemperatureButton(_ sender: Any) {
        inputValidation()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let segueTaransition = segue.identifier
        if segueTaransition == "convertTemp" {
            let segueDestination = segue.destination as! ResultViewController
            segueDestination.temp = Double(tempTextField.text!)!
        }
    }
    

}

