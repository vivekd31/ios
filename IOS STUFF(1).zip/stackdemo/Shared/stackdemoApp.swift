//
//  stackdemoApp.swift
//  Shared
//
//  Created by student on 9/14/21.
//

import SwiftUI

@main
struct stackdemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
