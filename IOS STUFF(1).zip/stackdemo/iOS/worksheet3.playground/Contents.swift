import UIKit

var greeting = "Hello, playground"

class Circle{
    var radius:Double

    init(){
        radius=5.0
    }
    
    func getArea()->Double{
        return Double.pi*radius*radius
    }
    
    func getPerimeter()->Double{
        return 2*Double.pi*radius
    }

}
let Circle1 = Circle()

let Circlearea = Circle1.getArea()
print(Circle1.getArea())

let Circleperimeter = Circle1.getPerimeter()
print(Circle1.getPerimeter())

