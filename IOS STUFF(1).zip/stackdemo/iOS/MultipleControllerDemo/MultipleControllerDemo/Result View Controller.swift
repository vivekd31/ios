//
//  Result View Controller.swift
//  MultipleControllerDemo
//
//  Created by student on 10/19/21.
//

import UIKit

class Result_View_Controller: NSObject {

}
