//
//  ResultViewController.swift
//  MultipleControllerDemo
//
//  Created by student on 10/19/21.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var EnteredAmountOutlet: UILabel!
    
    @IBOutlet weak var EnteredDiscRateoutlet: UILabel!
    
    var amount = ""
    var discRate = ""
    var finalPrice = ""
    
    
    @IBOutlet weak var PriceAfterDiscOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        EnteredAmountOutlet.text = EnteredAmountOutlet.text! + amount
        
        EnteredDiscRateoutlet.text = EnteredDiscRateoutlet.text! + discRate
        
        PriceAfterDiscOutlet.text = PriceAfterDiscOutlet.text! + finalPrice
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
