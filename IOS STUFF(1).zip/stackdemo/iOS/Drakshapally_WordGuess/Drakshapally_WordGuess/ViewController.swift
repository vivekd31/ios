//
//  ViewController.swift
//  Drakshapally_WordGuess
//
//  Created by student on 10/26/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsMissedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var guessLetterButtonPressed: UIButton!
    
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var playAgainButtonPressed: UIButton!
    
    @IBOutlet weak var imageView: UIImageView!
    var wordsToGuess = [["ATHLETE","A person who plays the game"],
                        ["MONUMENT","A historical structure"],["BIKE","A Two Wheeler Vehicle"],["CAR","A Four Wheeler Vehicle"],["LEADER","A person who leads the group of people"]]
    var hint = ""
    var images = ["Athlete3","Monument3","Bike3","Car3","Leader3"]
    var wordToGuess = ""
    var wordToGuessIndex = 0
    var lettersGuessed = ""
    let maxNumberOfWrongGuesses = 10
    var wrongGuessesRemaining = 10
    var guessCount = 0
    var wordsGuessedCount = 0
    var wordsMissedCount = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        wordToGuess = wordsToGuess[wordToGuessIndex][0]
               hint = wordsToGuess[wordToGuessIndex][1]
               hintLabel.text = "HINT: " + hint
               
               totalWordsLabel.text = "Words in Game: \(wordsToGuess.count)"
               wordsRemainingLabel.text = "Words Remaining:\(wordsToGuess.count)"
               formatUserGuessLabel()
        
               guessLetterButtonPressed.isEnabled = false
               
               playAgainButtonPressed.isHidden = true
           }
           
           func updateWordCountLabels(){
               
               wordsMissedLabel.text = "Words Missed: \(wordsMissedCount)"
               wordsGuessedLabel.text = "Words Guessed: \(wordsGuessedCount)"
               
               wordsRemainingLabel.text = "Words Remaining:\(wordsToGuess.count - (wordsGuessedCount + wordsMissedCount))"
           }
           
           func updateUIAfterGuess(){
               
               guessLetterField.resignFirstResponder()
               
               guessLetterField.text = ""
           }
           
           func formatUserGuessLabel() {
               var revealedWord = ""
               lettersGuessed += guessLetterField.text!
               
               for letter in wordToGuess {
                   if lettersGuessed.contains(letter) {
                       revealedWord = revealedWord + " \(letter)"
                   } else {
                       revealedWord += " _"
                   }
               }
               revealedWord.removeFirst()
               userGuessLabel.text = revealedWord
           }
           
           
           
           func guessALetter() {
               formatUserGuessLabel()
               guessCount += 1
               
               
               let currentLetterGuessed = guessLetterField.text!
               
               if !wordToGuess.contains(currentLetterGuessed) {
                   
                   wrongGuessesRemaining = wrongGuessesRemaining - 1
                   
               }
               
               let revealedWord = userGuessLabel.text!
               
               if wrongGuessesRemaining == 0 {
                   
                   playAgainButtonPressed.isHidden = false
                   guessLetterField.isEnabled = false
                   guessLetterButtonPressed.isEnabled = false
                   
                   guessCountLabel.text = "You have used all the available guesses, Please start again"
                   wordsMissedCount += 1
                   updateWordCountLabels()
                   updateImageView()
               } else if !revealedWord.contains("_") {
                  
                   playAgainButtonPressed.isHidden = false
                   guessLetterField.isEnabled = false
                   guessLetterButtonPressed.isEnabled = false
                   guessCountLabel.text = "You've got it! It took you \(guessCount) guesses to guess the word!"
                   wordsGuessedCount += 1
                   updateWordCountLabels()
                   updateImageView()
               } else {
                   // Update our guess count
                   let guess = ( guessCount == 1 ? "Guess" : "Guesses")
                   guessCountLabel.text = "You've Made \(guessCount) \(guess)"
               }
               
               if (wordsGuessedCount + wordsMissedCount) == wordsToGuess.count {
                   guessCountLabel.text = "Congratulations, You are done, Please start over again"
                   updateImageView()
               }
           }
    
    @IBAction func guessLetterFieldChanged(_ sender: Any) {
        if let letterGuessed = guessLetterField.text?.last {
          guessLetterField.text = "\(letterGuessed)"
          guessLetterButtonPressed.isEnabled = true
      } else {
          
          guessLetterButtonPressed.isEnabled = false
      }
    }
    
    
          
          
    
    
           
    @IBAction func doneKeyPressed(_ sender: Any) {
        guessALetter()
        updateUIAfterGuess()
        let letter = guessLetterField.text
        if letter?.isEmpty == true{
            guessLetterButtonPressed.isEnabled = false
        }
        else{
            guessLetterButtonPressed.isEnabled = true
        }
    }
    
    
        
           
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
            
            guessALetter()
            updateUIAfterGuess()
            let letter = guessLetterField.text
            if letter?.isEmpty == true{
                guessLetterButtonPressed.isEnabled = false
            }
            else{
                guessLetterButtonPressed.isEnabled = true
            }
        }
        
        @IBAction func playAgainButtonPressed(_ sender: UIButton) {
            imageView.isHidden = true
            wordToGuessIndex += 1
            if wordToGuessIndex == wordsToGuess.count {
                wordToGuessIndex = 0
                wordsGuessedCount = 0
                wordsMissedCount = 0
                updateWordCountLabels()
            }
            wordToGuess = wordsToGuess[wordToGuessIndex][0]
            hint = wordsToGuess[wordToGuessIndex][1]
            hintLabel.text = "HINT: " + hint
            
            playAgainButtonPressed.isHidden = true
            guessLetterField.isEnabled = true
            guessLetterButtonPressed.isEnabled = false
            
            wrongGuessesRemaining = maxNumberOfWrongGuesses
            lettersGuessed = ""
            formatUserGuessLabel()
            guessCountLabel.text = "You've Made 0 Guesses"
            guessCount = 0
        }
                func updateImageView(){
                    imageView.isHidden = false
                    imageView.image = UIImage(named: images[wordToGuessIndex])
                    let originalImageFrame = imageView.frame
                    let widthShrink: CGFloat = 10
                    let heightShrink: CGFloat = 10
                    let newFrame = CGRect(
                    x: imageView.frame.origin.x + widthShrink,
                    y: imageView.frame.origin.y + heightShrink,
                    width: imageView.frame.width - widthShrink,
                    height: imageView.frame.height - heightShrink)
                    imageView.frame = newFrame
                    UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 10.0,  animations: {
                        self.imageView.frame = originalImageFrame
                    })
    }
        
    }


