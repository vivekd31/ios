//
//  ViewController.swift
//  COURSEDISPLAYAPP
//
//  Created by student on 9/23/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var PrevButton: UIButton!
    @IBOutlet weak var ImageDIsplay: UIImageView!
    @IBOutlet weak var coursenumber: UILabel!
    @IBOutlet weak var coursetitle: UILabel!
    @IBOutlet weak var coursesemester: UILabel!
    var courses  = [["44555", "Network Security", "fall"],
        ["44643", "Mobile Edge Computing", "spring"],
        ["44443", "Data Streaming", "summer"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //details of the first course (0 index) including image.
        coursenumber.text = courses[0][0]
        coursetitle.text = courses[0][1]
        coursesemester.text = courses[0][2]
        //previous button should be disabled.
        PrevButton.isEnabled = false
    }

    @IBAction func previous(_ sender: Any) {
    }
    
    @IBAction func next(_ sender: Any) {
    }
}

