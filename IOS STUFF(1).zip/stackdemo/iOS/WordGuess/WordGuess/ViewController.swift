//
//  ViewController.swift
//  WordGuess
//
//  Created by student on 9/30/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displaylabel: UILabel!
    
    @IBOutlet weak var hintlabel: UILabel!
    
    @IBOutlet weak var textbox: UITextField!
    
    @IBOutlet weak var check: UIButton!
    
    @IBOutlet weak var playagain: UIButton!
    
    var words = [["SWIFT", "Programming Language"],
                ["DOG", "Animal"],
                ["CYCLE", "Two wheeler"],
                ["MACBOOK", "Apple device"]]
       
       var count = 0;
       var word = ""
       var lettersGuessed = ""
    
    @IBOutlet weak var statuslabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        check.isEnabled=false;
        displaylabel.text=""
        for _ in word {
            displaylabel.text! += "- "
        }
        hintlabel.text = "Hint: "+words[count][1]
                statuslabel.text = ""
    }

    @IBAction func TextBox(_ sender: Any) {
    }
    
    @IBAction func Check(_ sender: Any) {
    }
    
    @IBAction func PlayAgain(_ sender: Any) {
    }
}

