//
//  ViewController.swift
//  Coordinatedemo
//
//  Created by student on 10/7/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Image: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let minx = Image.frame.minX
        let miny = Image.frame.minY
        print(minx,miny)
        
        let maxx = Image.frame.maxX
        let maxy = Image.frame.maxY
        print(maxx,maxy)
        
        let midx = Image.frame.midX
        let midy = Image.frame.midY
        print(midx,midy)
        
        let w = Image.frame.width
        let h = Image.frame.height
        print(w,h)
        
        //change the location of the imageview to the bottom right corner
        Image.frame.origin.x = 314
        Image.frame.origin.y = 796
        
        //change the location of the imageview to the bottom left corner
        Image.frame.origin.x = 0
        Image.frame.origin.y = 796
        
        //Change the location of the imageview to the top left corner
        Image.frame.origin.x = 0
        Image.frame.origin.y = 0
        
        //Change the location of the imageview to the top right corner
        
        Image.frame.origin.x = 314
        Image.frame.origin.y = 0
        
        //Change the location of the imageview to the center of the screen
        
        Image.frame.origin.x = 157
        Image.frame.origin.y = 398
    }

    @IBAction func SubmitButton(_ sender: Any) {
        //When the submit button is clicked,the width and height should be increased by 100.
        var w = Image.frame.width
         w+=100
        
        var h = Image.frame.height
        h+=100
        //The image view must be in the center of the screen.
        let x = Image.frame.origin.x-50
        let y = Image.frame.origin.y-50
        
        let imageFrame = CGRect(x: x, y: y,width: w, height: h)
        
        //Image.frame = imageFrame
        
      //  UIView.animate(withDuration: 1,
            //           delay:3,animations: {
        //    self.Image.frame = imageFrame
          //  self.Image.alpha = 1
                        
            
       // })
              
        UIView.animate(withDuration: 1, delay: 1, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {self.Image.frame = imageFrame})
    }
    
}

