import Foundation
import UIKit

struct HeroStats : Codable{
    var localized_name : String
    var primary_attr : String
    var attack_type : String
    var legs : Int
}
